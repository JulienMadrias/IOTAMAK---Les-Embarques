from enum import *
class Color(Enum):
    BLACK= auto()
    RED=auto()
    BLUE=auto()
    GREEN=auto()
    YELLOW=auto()